### Hexlet tests and linter status:
[![Actions Status](https://github.com/noname7772/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/noname7772/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/665b65ed6a016731aa2d/maintainability)](https://codeclimate.com/github/noname7772/python-project-49/maintainability)
