import brain_games.games.even as brain_even
import brain_games.engine as engine


def main():
    engine.run_game(brain_even)


if __name__ == '__main__':
    main()
